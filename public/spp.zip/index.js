require("dotenv").config();
const fs = require('fs')
const { Reader } = require('thaismartcardreader.js')
const path = require('path')
const { default: axios } = require('axios')
const myReader = new Reader()
const express = require('express')
const port = 44121;

process.on('uncaughtException', function (err) {
	console.log('ไม่สามารถอ่านบัตรได้กรุณาลองอีกครั้ง!');
});

myReader.on('device-activated', async (event) => {
	try {
		console.log('Device-Activated')
		console.log(event.name)
		console.log('=============================================')
	} catch (error) {
		console.log("error", error)
	}
})

myReader.on('error', async (err) => {
	try {

	} catch (error) {

	}
})

myReader.on('image-reading', (percent) => {
	console.log(percent)
})


myReader.on('card-inserted', async (person) => {
	try {
		const cid = await person.getCid()
		const thName = await person.getNameTH()
		const enName = await person.getNameEN()
		const dob = await person.getDoB()
		const issueDate = await person.getIssueDate()
		const expireDate = await person.getExpireDate()
		const address = await person.getAddress()
		const issuer = await person.getIssuer()
		const photo = await person.getPhoto()
		// convert to base64
		const photoBuff = Buffer.from(photo).toString('base64')
		const data = {
			cid,
			thName,
			enName,
			dob,
			issueDate,
			expireDate,
			address,
			issuer,
			photo: photoBuff
		}
		const webhook_url = process.env.WEBHOOK_URL;
		const instance = axios.create({
			baseURL: webhook_url,
			timeout: 3000,
			headers: { 'Content-Type': 'application/json' }
		})
		const token = getToken()
		const postData = await instance.post(`/?vid=${process.env.VILLAGE_ID}&token=${token}`, data)
		console.log("[Alert]", postData?.data?.data?.message || "No Server Response!")
	} catch (error) {
		console.log("error", error)
	}

})



function getToken() {
	const token = require("./token.json")
	return token.data
}
function writeToken(token) {
	const tokenPath = path.join(__dirname, 'token.json')
	const data = { data: token }
	fs.writeFileSync(tokenPath, JSON.stringify(data))
}

const app = express();
app.get('/setToken', (req, res) => {
	const token = req.query.token
	writeToken(token)
	res.send('ลิงค์กับตัวอ่านบัตรเรียบร้อยแล้ว...')
})
app.listen(port, () => {
	console.log(`Reader running on port ${port}`)
})
myReader.on('device-deactivated', () => { console.log('device-deactivated') })